import sys,time,json
from pathlib import Path
sys.path.insert(0,'/root/CachePilot/scripts')
from validate_environment import Service,ROOT,API,CACHE,request,get_text,write_json
out=ROOT/'artifacts/ttl-complete-2026-09-24';out.mkdir(exist_ok=False)
cache=Service(['bash',str(ROOT/'scripts/lmcache-server.sh')],out/'lmcache.log')
engine=Service(['bash',str(ROOT/'scripts/serve.sh'),'fifo'],out/'vllm.log')
try:
 cache.start(CACHE+'/status');engine.start(API+'/health')
 request(out,'cold');request(out,'hot');request(out,'pressure','Different prefix '+('tool context. '*600))
 engine.stop()
 start=time.monotonic();initial=None
 while time.monotonic()-start<700:
  s=json.loads(get_text(CACHE+'/status'));elapsed=time.monotonic()-start
  if initial is None:initial=s['active_sessions']
  row={'elapsed_seconds':elapsed,'active_sessions':s['active_sessions'],'registered_gpu_ids':s['registered_gpu_ids'],'l1':s['storage_manager']['l1_manager']}
  with (out/'observations.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  print(json.dumps({k:row[k] for k in ['elapsed_seconds','active_sessions','registered_gpu_ids']}),flush=True)
  if not s['active_sessions'] and elapsed>5:
   write_json(out/'result.json',{'initial_sessions':initial,'sessions_cleared':True,'elapsed_seconds':elapsed,'last_observation':row});break
  time.sleep(15)
 else:write_json(out/'result.json',{'initial_sessions':initial,'sessions_cleared':False,'last_observation':row})
finally:
 engine.stop();cache.stop()