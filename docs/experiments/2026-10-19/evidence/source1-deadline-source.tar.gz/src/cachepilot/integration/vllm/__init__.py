"""CachePilot vllm components."""
