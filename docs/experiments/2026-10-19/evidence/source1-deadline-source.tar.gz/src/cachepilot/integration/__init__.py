"""CachePilot integration components."""
