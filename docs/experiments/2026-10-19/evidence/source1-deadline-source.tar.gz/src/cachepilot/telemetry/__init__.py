"""CachePilot telemetry components."""
