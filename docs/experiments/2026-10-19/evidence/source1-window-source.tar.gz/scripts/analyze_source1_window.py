"""Summarize passive source-event 1 pending-window observations."""
import json
from pathlib import Path


def analyze_rows(rows):
    observations = [row for row in rows
        if row.get("event") == "source1_window_snapshot"
        and row.get("request_id") == "cmpl-cachepilot-trace-0001-0"]
    observations.sort(key=lambda row: row["observation"])
    if not observations:
        return dict(passed=False, reason="no_source1_pending_observations",
                    observations=0, first_hash_loss=None, safe_windows=[])
    losses = [row for row in observations
        if row.get("all_pending_hashes_intact") is False]
    windows = [row for row in observations
        if row.get("actionable_current_front") is True]
    return dict(passed=True, observations=len(observations),
        first_hash_loss=None if not losses else dict(
            observation=losses[0]["observation"], stage=losses[0]["stage"],
            pending=losses[0]["pending"]),
        safe_windows=[dict(observation=row["observation"], stage=row["stage"],
            pending=row["pending"], free_blocks=row["free_blocks"],
            reserve_blocks=row["reserve_blocks"],
            max_safe_protection_blocks=row["max_safe_protection_blocks"])
            for row in windows],
        first_pending=observations[0], last_pending=observations[-1],
        conclusion=("safe_candidate_window_observed" if windows else
                    "no_safe_candidate_window_observed"))


def audit(directory):
    root = Path(directory)
    rows = [json.loads(line) for path in sorted((root / "handoffs").glob("*.jsonl"))
        for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return analyze_rows(rows)


def audit_run(directory):
    """Independently recheck fixed input, frozen source and service closure."""
    import hashlib
    import tarfile
    from collections import Counter
    from analyze_whole_step_identity import analyze_cell, read_rows
    from audit_generation_pilot import audit_rows as generation_audit
    from audit_real_structure import audit as input_audit
    from run_arrival_matrix import digest
    from run_fixed_baselines import KV_BYTES, read, token_gate
    from run_generation_matrix import generation_closed
    from run_real_structure_pilot import TRACE_SHA
    from run_reference_baselines import resource_gate
    from run_whole_step_identity_diagnostic import configuration
    import run_protection_ablation as ablation
    root = Path(directory)
    plan, trace = read(root / "plan.json"), read(root / "trace.json")
    cell = root / "zero-r0"
    result = read(cell / "result.json")
    signature = plan["signature"]
    expected = configuration("zero")
    expected.update(kv_connector="Source1WindowConnector",
                    kv_connector_module_path="scripts.source1_window_connector")
    with tarfile.open(root / "frozen-source.tar.gz") as archive:
        members = [member for member in archive.getmembers() if member.isfile()]
        frozen = {member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                  for member in members}
    manifest = read(cell / "run-manifest.json")
    handoffs = read_rows(cell / "handoffs", "*.jsonl")
    service = read_rows(cell / "owned-events", "*.jsonl")
    generation = generation_audit(handoffs, service, result)
    summary = ablation.merge_protection_summary(cell / "protection-summary")
    window = analyze_rows(handoffs)
    conservation = [Counter((row["request_id"], row["sequence"], row["kind"])
        for row in service if row.get("event") == phase)
        for phase in ("transfer_submitted", "terminal_seen", "transfer_retired")]
    checks = dict(
        plan=plan["stage"] == "source1-window" and plan["labels"] == ["zero"],
        config=signature["configs"] == {"zero": expected} == {"zero": read(cell / "config.json")},
        source=len(frozen) == len(members) and frozen == signature["source_sha256"] == manifest["source_sha256"],
        input=input_audit(root / "input/built", root / "input/source", root / "input/catalogue.json") == plan["provenance"],
        trace=digest(trace) == TRACE_SHA == signature["trace_sha256"] == manifest["trace_sha256"] == digest(read(cell / "trace.json"))
            and trace == read(root / "input/built/trace.json"),
        budget=signature["kv_cache_bytes"] == manifest["kv_cache_bytes"] == KV_BYTES,
        requests=result["passed"] and token_gate(cell, trace),
        resources=resource_gate("lazy", result),
        identity=analyze_cell(cell, "zero")["passed"],
        generation=generation["passed"] and generation_closed(read(cell / "generation-summary.json")),
        zero_protection=summary["committed_batches"] == summary["peak_pinned_blocks"] == 0,
        protection_closed=summary["shutdown_closed"],
        transfers=bool(conservation[0]) and conservation[0] == conservation[1] == conservation[2]
            and all(count == 1 for count in conservation[0].values())
            and all(row.get("succeeded") is True for row in service if row.get("event") == "transfer_retired"),
        logs=not ablation.service_error_report(cell, read(cell / "shutdown-context.json"))["fatal_errors"],
        observations=window["passed"])
    return dict(complete=all(checks.values()), checks=checks, window=window,
        generation=generation, requests=result["requests"], output_tokens=result["output_tokens"],
        scope="Passive lifecycle diagnosis only; no performance or intervention conclusion")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    print(json.dumps(audit(args.directory), indent=2, sort_keys=True))
