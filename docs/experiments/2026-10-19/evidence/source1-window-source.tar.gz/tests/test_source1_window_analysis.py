import unittest

from analyze_source1_window import analyze_rows


def observation(serial, *, intact=True, safe=False, stage="policy_drain_before"):
    return dict(event="source1_window_snapshot", request_id="cmpl-cachepilot-trace-0001-0",
        observation=serial, stage=stage, all_pending_hashes_intact=intact,
        actionable_current_front=safe, pending=[], free_blocks=100,
        reserve_blocks=50, max_safe_protection_blocks=32)


class Source1WindowAnalysisTests(unittest.TestCase):
    def test_missing_observations_fails_closed(self):
        result = analyze_rows([])
        self.assertFalse(result["passed"])
        self.assertEqual(result["reason"], "no_source1_pending_observations")

    def test_safe_window_before_hash_loss_is_preserved(self):
        result = analyze_rows([observation(1, safe=True), observation(2, intact=False)])
        self.assertEqual(result["conclusion"], "safe_candidate_window_observed")
        self.assertEqual(result["safe_windows"][0]["observation"], 1)
        self.assertEqual(result["first_hash_loss"]["observation"], 2)

    def test_no_safe_window_is_not_mistaken_for_failure(self):
        result = analyze_rows([observation(1), observation(2, intact=False)])
        self.assertTrue(result["passed"])
        self.assertEqual(result["conclusion"], "no_safe_candidate_window_observed")

    def test_unrelated_request_rows_are_ignored(self):
        result = analyze_rows([dict(observation(1), request_id="other")])
        self.assertFalse(result["passed"])


if __name__ == "__main__":
    unittest.main()
