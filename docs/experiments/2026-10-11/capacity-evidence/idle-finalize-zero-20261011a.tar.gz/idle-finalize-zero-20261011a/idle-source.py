"""Serial scheduler quiescence policy; never frees GPU blocks or submits STORE."""
from scripts.owned_service_protocol import wire_id


def finalize_idle_pending(connector, scheduler):
    # Paused/streaming/remote-retrieve/deferred-free requests are not idle.
    if any((scheduler.requests, scheduler.running, scheduler.waiting,
            scheduler.skipped_waiting, scheduler.deferred_frees)):
        return 0
    manager = connector._lazy_offload_manager
    if manager._requests.in_flight_request_ids() or connector._handoffs.pending:
        return 0
    bounded = connector._bounded
    if bounded is not None and (bounded.prepared or bounded.inflight):
        return 0
    policy = manager._policy
    pending = list(policy._pending.items())
    # Bounded to the service ownership admission limit; no engine wake/spin.
    if len(pending) > 256:
        raise RuntimeError('Idle pending cardinality exceeds supported limit')
    plans = []
    for rid, ops in pending:
        if not ops or not manager._requests.is_finished(rid):
            raise RuntimeError('Idle candidate is not a finished pending request')
        identities = {wire_id(p.store_metadata) for p in ops}
        if len(identities) != 1:
            raise RuntimeError('Idle pending generation mismatch')
        identity, = identities
        if not connector.scheduler_adapter.req_clients or any(
                c.identities.get(rid) != identity
                for c in connector.scheduler_adapter.req_clients.values()):
            raise RuntimeError('Idle pending differs from current wire identity')
        plans.append((rid, identity, [(p.store_metadata.op.start,
                                     p.store_metadata.op.end) for p in ops]))
    # All candidates validated before mutating any policy entry.
    total = 0
    for rid, identity, ranges in plans:
        connector._handoff_record('idle_pending_drop_planned', request_id=rid,
            wire_id=identity, ranges=ranges, reason='scheduler_quiescent')
        count = policy.drop_request(rid)
        manager._release_session(rid)
        connector.scheduler_adapter.end_session(rid)
        connector._handoff_record('idle_pending_dropped', request_id=rid,
            wire_id=identity, ranges=ranges, dropped=count,
            reason='scheduler_quiescent', acquired_pins=0, submitted_stores=0)
        total += count
    return total


def install_idle_scheduler(scheduler_type):
    if getattr(scheduler_type.has_requests, '_cachepilot_idle_finalize', False):
        return
    original = scheduler_type.has_requests

    def has_requests(scheduler):
        busy = original(scheduler)
        connector = scheduler.connector
        if not busy and getattr(connector, '_idle_finalize', False):
            finalize_idle_pending(connector, scheduler)
        return busy
    has_requests._cachepilot_idle_finalize = True
    scheduler_type.has_requests = has_requests
